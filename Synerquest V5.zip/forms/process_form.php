<?php
if(isset($_POST['submit'])){
    // Retrieve form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Set email recipient
    $to = "dspunay.synerquest@gmail.com";

    // Set email subject
    $subject = "Contact Form Submission from $name";

    // Set email message
    $email_body = "Name: $name\nEmail: $email\n\n$message";

    // Set email headers
    $headers = "From: $email";

    // Send email
    if(mail($to, $subject, $email_body, $headers)){
        echo "Thank you for contacting us!";
    } else {
        echo "Failed to send email. Please try again.";
    }
}
?>