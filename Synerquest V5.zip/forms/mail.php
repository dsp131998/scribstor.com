<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

$errors = array(); // Initialize an empty array for errors
$success = false; // Initialize a flag for successful submission
ini_set('SMTP', 'smtp.gmail.com');
ini_set('smtp_port', 587);

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // Check if the form fields are empty
  if (empty($_POST['name'])) {
    $errors['name'] = 'Name is required';
  }
  if (empty($_POST['email'])) {
    $errors['email'] = 'Email is required';
  }
  if (empty($_POST['subject'])) {
    $errors['subject'] = 'Subject is required';
  }
  if (empty($_POST['message'])) {
    $errors['message'] = 'Message is required';
  }

  // Validate email address format
  if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = 'Invalid email address format';
  }

  // Check if there are any errors
  if (count($errors) == 0) {
    // Sanitize form data to prevent XSS attacks
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $subject = htmlspecialchars($_POST['subject']);
    $message = htmlspecialchars($_POST['message']);

    // Send the email
    $to = 'dspunay.synerquest@gmail.com';
    $body = "Name: $name\nEmail: $email\nSubject: $subject\nMessage:\n$message";
    $headers = "From: $name <$email>\r\nReply-To: $email\r\n";
    if (mail($to, $subject, $body, $headers)) {
      $success = true;
    } else {
      $errors['mail'] = 'Failed to send email';
    }
  }
}

?>