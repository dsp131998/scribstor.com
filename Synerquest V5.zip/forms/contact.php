<?php
if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];
    $to = "ranger@synerquest.com";
    $subject = "New Contact Form Submission";
    $body = "Name: $name\nEmail: $email\n\n$message";

    if(mail($to, $subject, $body)){
        echo "<p>Your message has been sent. Thank you!</p>";
    } else{
        echo "<p>There was an error sending your message. Please try again later.</p>";
    }
}
?>